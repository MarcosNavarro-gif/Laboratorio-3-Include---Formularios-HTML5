<?php
// includes/footer.php - Pie de página modular común
?>
<footer class="bg-dark text-white text-center py-4 mt-auto">
    <div class="container">
        <!-- Eslogan o identificación institucional -->
        <p class="mb-1 fw-semibold">Portal de Gestión de Aspirantes — Facultad de Ingeniería de Sistemas Computacionales — Universidad Tecnológica de Panamá</p>

        <!-- Redes sociales y enlaces rápidos -->
        <div class="mb-2">
            <a href="https://github.com/" target="_blank" rel="noopener noreferrer" class="text-white text-decoration-none mx-2 small">
                <i class="bi bi-github"></i> GitHub
            </a> |
            <a href="https://www.linkedin.com/" target="_blank" rel="noopener noreferrer" class="text-white text-decoration-none mx-2 small">
                <i class="bi bi-linkedin"></i> LinkedIn
            </a> |
            <a href="mailto:soporte@utp.ac.pa" class="text-white text-decoration-none mx-2 small">
                <i class="bi bi-envelope"></i> Soporte Técnico
            </a>
        </div>

        <!-- Copyright con año dinámico en PHP -->
        <p class="text-white-50 small mb-0">
            &copy; <?php echo date('Y'); ?> Universidad Tecnológica de Panamá. Todos los derechos reservados.
        </p>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
<!-- Cierre de las etiquetas HTML abiertas en el header.php -->
</body>
</html>
