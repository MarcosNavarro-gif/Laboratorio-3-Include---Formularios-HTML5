<?php
// index.php - Formulario de registro de aspirantes
session_start();

// Token CSRF: evita que el formulario sea enviado desde otro sitio
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$hoy = date('Y-m-d'); // Fecha máxima permitida en el campo de nacimiento

include 'includes/header.php';
?>

<main class="flex-grow-1 py-4">
    <section class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-md-8 col-lg-6">

                <h1 class="h3 fw-bold mb-3">Formulario de Registro de Aspirantes</h1>

                <div class="card shadow-sm border-0">
                    <div class="card-body p-4">

                        <!-- enctype multipart/form-data: obligatorio para poder enviar la foto -->
                        <form action="procesar.php" method="POST" enctype="multipart/form-data">
                            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">

                            <div class="mb-3">
                                <label for="nombre" class="form-label fw-bold">Nombre (Requerido):</label>
                                <input type="text" class="form-control" id="nombre" name="nombre"
                                       placeholder="Ej: Sofía" maxlength="50" required>
                            </div>

                            <div class="mb-3">
                                <label for="apellido" class="form-label fw-bold">Apellido (Requerido):</label>
                                <input type="text" class="form-control" id="apellido" name="apellido"
                                       placeholder="Ej: Rodríguez" maxlength="50" required>
                            </div>

                            <div class="mb-3">
                                <label for="identificacion" class="form-label fw-bold">Identificación (Requerido):</label>
                                <input type="text" class="form-control" id="identificacion" name="identificacion"
                                       placeholder="Ej: 8-123-456" maxlength="20" required>
                            </div>

                            <div class="mb-3">
                                <label for="fecha_nacimiento" class="form-label fw-bold">Fecha de Nacimiento (Requerido):</label>
                                <input type="date" class="form-control" id="fecha_nacimiento" name="fecha_nacimiento"
                                       max="<?php echo $hoy; ?>" required>
                            </div>

                            <div class="mb-3">
                                <span class="form-label fw-bold d-block">Sexo (Requerido):</span>
                                <div class="d-flex gap-2">
                                    <input type="radio" class="btn-check" name="sexo" id="sexoH" value="Hombre" required>
                                    <label class="btn btn-outline-secondary flex-fill" for="sexoH">Hombre</label>

                                    <input type="radio" class="btn-check" name="sexo" id="sexoM" value="Mujer">
                                    <label class="btn btn-outline-secondary flex-fill" for="sexoM">Mujer</label>
                                </div>
                            </div>

                            <div class="mb-4">
                                <label for="foto" class="form-label fw-bold">Fotografía del Aspirante (png, jpg, jpeg, gif, webp):</label>
                                <input type="file" class="form-control" id="foto" name="foto"
                                       accept=".png,.jpg,.jpeg,.gif,.webp" required>
                            </div>

                            <button type="submit" class="btn btn-primary w-100">Registrar Aspirante</button>
                        </form>

                    </div>
                </div>

            </div>
        </div>
    </section>
</main>

<?php include 'includes/footer.php'; ?>
