<?php
// procesar.php - Backend: valida, estandariza y guarda la foto del aspirante
session_start();

// Solo se acepta acceso por POST (si entran directo por URL, se regresa al formulario)
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}

// ---------- Funciones auxiliares ----------
// Limpieza: quita espacios y etiquetas HTML/PHP
function limpiar(string $valor): string
{
    return strip_tags(trim($valor));
}

// Salida segura (previene XSS)
function e(string $valor): string
{
    return htmlspecialchars($valor, ENT_QUOTES, 'UTF-8');
}

// ---------- Variables ----------
$errores         = [];
$directorioFotos = __DIR__ . '/uploaded_files/';
$extPermitidas   = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
$mimePermitidos  = [
    'image/jpeg' => 'jpg',
    'image/png'  => 'png',
    'image/gif'  => 'gif',
    'image/webp' => 'webp',
];
$tamanoMaximo = 2 * 1024 * 1024; // 2 MB

// ---------- 1. Seguridad: token CSRF ----------
$token = $_POST['csrf_token'] ?? '';
if (empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $token)) {
    $errores[] = 'Solicitud no válida (token de seguridad incorrecto). Vuelva a cargar el formulario.';
}

// ---------- 2. Recibir y sanear datos ----------
$nombre         = limpiar($_POST['nombre'] ?? '');
$apellido       = limpiar($_POST['apellido'] ?? '');
$identificacion = limpiar($_POST['identificacion'] ?? '');
$fechaNac       = limpiar($_POST['fecha_nacimiento'] ?? '');
$sexo           = limpiar($_POST['sexo'] ?? '');

// ---------- 3. Validar campos vacíos ----------
if ($nombre === '')         $errores[] = 'El nombre es obligatorio.';
if ($apellido === '')       $errores[] = 'El apellido es obligatorio.';
if ($identificacion === '') $errores[] = 'La identificación es obligatoria.';
if ($fechaNac === '')       $errores[] = 'La fecha de nacimiento es obligatoria.';
if ($sexo === '')           $errores[] = 'Debe seleccionar el sexo.';

// ---------- 4. Estandarizar textos ----------
// Equivale a ucwords(strtolower()), pero con soporte UTF-8 (tildes y ñ)
$nombre   = mb_convert_case(mb_strtolower($nombre, 'UTF-8'), MB_CASE_TITLE, 'UTF-8');
$apellido = mb_convert_case(mb_strtolower($apellido, 'UTF-8'), MB_CASE_TITLE, 'UTF-8');
$identificacion = mb_strtoupper($identificacion, 'UTF-8'); // Mayúsculas cerradas

// ---------- 5. Validar formato ----------
if ($nombre !== '' && !preg_match("/^[\p{L}\s'\-]{2,50}$/u", $nombre)) {
    $errores[] = 'El nombre solo puede contener letras (2 a 50 caracteres).';
}
if ($apellido !== '' && !preg_match("/^[\p{L}\s'\-]{2,50}$/u", $apellido)) {
    $errores[] = 'El apellido solo puede contener letras (2 a 50 caracteres).';
}
if ($identificacion !== '' && !preg_match('/^[A-Z0-9\-]{3,20}$/', $identificacion)) {
    $errores[] = 'La identificación solo puede contener letras, números y guiones (3 a 20 caracteres).';
}
if ($sexo !== '' && !in_array($sexo, ['Hombre', 'Mujer'], true)) {
    $errores[] = 'El valor de sexo no es válido.';
}

// ---------- 6. Validar fecha y edad (18 a 70 años) ----------
$edad = null;
if ($fechaNac !== '') {
    $fecha = DateTime::createFromFormat('Y-m-d', $fechaNac);
    if (!$fecha || $fecha->format('Y-m-d') !== $fechaNac) {
        $errores[] = 'La fecha de nacimiento no es válida.';
    } else {
        $hoy = new DateTime('today');
        if ($fecha > $hoy) {
            $errores[] = 'La fecha de nacimiento no puede ser futura.';
        } else {
            $edad = $fecha->diff($hoy)->y;
            if ($edad < 18 || $edad > 70) {
                $errores[] = "La edad del aspirante ($edad años) debe estar entre 18 y 70 años.";
            }
        }
    }
}

// ---------- 7. Validar la foto ----------
$foto = $_FILES['foto'] ?? null;
$mimeFoto = '';

if (!$foto || $foto['error'] === UPLOAD_ERR_NO_FILE) {
    $errores[] = 'Debe seleccionar una fotografía.';
} elseif ($foto['error'] !== UPLOAD_ERR_OK) {
    $errores[] = 'Ocurrió un error al subir la fotografía (código ' . (int)$foto['error'] . ').';
} else {
    $extension = strtolower(pathinfo($foto['name'], PATHINFO_EXTENSION));

    if (!in_array($extension, $extPermitidas, true)) {
        $errores[] = 'Extensión no permitida. Use: ' . implode(', ', $extPermitidas) . '.';
    } elseif ($foto['size'] > $tamanoMaximo) {
        $errores[] = 'La fotografía no debe superar los 2 MB.';
    } else {
        // Verificamos el contenido real del archivo, no solo su extensión
        $finfo    = new finfo(FILEINFO_MIME_TYPE);
        $mimeFoto = $finfo->file($foto['tmp_name']);

        if (!isset($mimePermitidos[$mimeFoto]) || getimagesize($foto['tmp_name']) === false) {
            $errores[] = 'El archivo no es una imagen válida.';
        }
    }
}

// ---------- 8. Guardar la foto (solo si todo es válido) ----------
$fotoBase64 = '';
$nombreFoto = '';

if (empty($errores)) {
    if (!is_dir($directorioFotos)) {
        mkdir($directorioFotos, 0755, true);
    }

    // Nombre aleatorio: evita sobrescribir archivos y nombres maliciosos
    $nombreFoto = date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.' . $mimePermitidos[$mimeFoto];
    $destino    = $directorioFotos . $nombreFoto;

    if (!move_uploaded_file($foto['tmp_name'], $destino)) {
        $errores[] = 'No se pudo guardar la fotografía en el servidor.';
    } else {
        // La carpeta uploaded_files/ está bloqueada desde el navegador (.htaccess),
        // por eso mostramos la imagen leyéndola desde el servidor.
        $fotoBase64 = 'data:' . $mimeFoto . ';base64,' . base64_encode(file_get_contents($destino));
    }
}

include 'includes/header.php';
?>

<main class="flex-grow-1 py-4">
    <section class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-md-8 col-lg-6">

                <?php if (!empty($errores)): ?>

                    <h1 class="h3 fw-bold mb-3">No se pudo registrar al aspirante</h1>
                    <div class="alert alert-danger" role="alert">
                        <p class="fw-bold mb-2">Corrija los siguientes errores:</p>
                        <ul class="mb-0">
                            <?php foreach ($errores as $error): ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    <a href="index.php" class="btn btn-secondary">Volver al formulario</a>

                <?php else: ?>

                    <h1 class="h3 fw-bold mb-3">Aspirante registrado correctamente</h1>
                    <div class="card shadow-sm border-0">
                        <div class="card-body p-4">
                            <div class="text-center mb-3">
                                <img src="<?php echo $fotoBase64; ?>" alt="Fotografía del aspirante"
                                     class="img-thumbnail rounded-circle"
                                     style="width: 150px; height: 150px; object-fit: cover;">
                            </div>

                            <table class="table table-borderless mb-0">
                                <tr>
                                    <th scope="row">Nombre:</th>
                                    <td><?php echo e($nombre); ?></td>
                                </tr>
                                <tr>
                                    <th scope="row">Apellido:</th>
                                    <td><?php echo e($apellido); ?></td>
                                </tr>
                                <tr>
                                    <th scope="row">Identificación:</th>
                                    <td><?php echo e($identificacion); ?></td>
                                </tr>
                                <tr>
                                    <th scope="row">Fecha de nacimiento:</th>
                                    <td><?php echo e(date('d/m/Y', strtotime($fechaNac))); ?></td>
                                </tr>
                                <tr>
                                    <th scope="row">Edad:</th>
                                    <td><?php echo (int)$edad; ?> años</td>
                                </tr>
                                <tr>
                                    <th scope="row">Sexo:</th>
                                    <td><?php echo e($sexo); ?></td>
                                </tr>
                                <tr>
                                    <th scope="row">Foto guardada como:</th>
                                    <td class="small text-muted"><?php echo e($nombreFoto); ?></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                    <a href="index.php" class="btn btn-primary mt-3">Registrar otro aspirante</a>

                <?php endif; ?>

            </div>
        </div>
    </section>
</main>

<?php include 'includes/footer.php'; ?>
